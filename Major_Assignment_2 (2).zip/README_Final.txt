Model Architecture:
Base Model:
EfficientNetB0 pretrained on ImageNet
Top Layer:
1)Added a GlobalAveragePooling layer to reduce the number of parameters
2)Drop out Regularization with drop out probability of 0.5
3)Added a Fully Connected Layer of 256 neurons, with a relu activation, followed by the corresponding softmax

Transfer Learning Strategy:
Initially loaded EfficientNetB0 with `include_top=False` and `weights='imagenet'. After trying for 10 epochs with pretrained weights, unfroze all layers for fine-tuning to get a good accuracy. Added custom dense layers on top as above. Used Horizontal flip for Data Augmentation and used a 80/20 train-validation split.

Performance Metrics:
Used the 2 very common Image classification performance metrics:
i)Actual Classification accuracy:(measure of how much the predictions align with the actual label)
Model achieved a classification accuracy of 70 percent on the validation set.

ii)Top 5 breed classification accuracy:(measure of how much the top 5 probable predicted breeds match with actual label)
Model achieved a classification accuracy of 83.27 percent on the validation set.

Instruction to lead the saved model:

from tensorflow.keras.models import load_model
model = load_model('/kaggle/working/final_model.h5')
predictions = model.predict(test_generator)

*test_generator flowing from a loaded dataframe